# 🚚 Delivery Map Route Viewer

This project uses Leaflet and OpenRouteService to display segmented delivery routes across multiple cities.

## 🌐 How to Deploy on GitHub Pages

1. **Create a GitHub repository** (e.g. `delivery-map`)
2. Upload the `index.html` file into the root of the repository
3. Go to **Settings → Pages**
4. Under "Source", choose `Deploy from a branch`
5. Select `main` as the branch and `/ (root)` as the folder
6. GitHub will provide a public link like:
   ```
   https://<your-username>.github.io/<your-repo-name>/
   ```

✅ Done! Your map is now live and accessible to anyone.

If route segments fail due to rate limits or routing errors, retry logic and fallbacks are built in.
